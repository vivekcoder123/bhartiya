<?php return array (
  'bank' => 'App\\Http\\Livewire\\Bank',
);